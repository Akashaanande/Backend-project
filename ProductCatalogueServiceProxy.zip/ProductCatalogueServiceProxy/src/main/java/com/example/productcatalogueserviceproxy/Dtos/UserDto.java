package org.example.productcatalogserviceproxy.Dtos;
import lombok.Getter;
import lombok.Setter;
@Getter
@Setter
public class UserDto {
    private String email;
    //private Set<Role> roles = new HashSet<>();
}