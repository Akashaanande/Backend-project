package com.example.productcatalogueserviceproxy.Controllers;

public class CategoryController {
}
