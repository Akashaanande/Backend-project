package com.example.productcatalogueserviceproxy.Repositories;

import com.example.productcatalogueserviceproxy.Models.Product;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import java.util.List;

@Repository

public interface ProductRepo extends JpaRepository<Product,Long> {
    Product save(Product product);

    Product findProductById(Long id);

    //Product updateProductById(Long id,Product product);
    List<Product> findProductByPriceBetween(Double low, Double high);
    List<Product> findAllByOrderByIdDesc();

    @Query("select p.title from Product p where p.id=?1")
    String getProductTitleFromId(Long id);
    @Query("select c.name from Product p join Category c on p.category.id=c.id where p.id =:id1")
    String getCategoryNameFromProductId(@Param("id1") Long id);
    List<Product> findAllByIsSpecialTrue();

    Page<Product> findByTitleEquals(String query, Pageable pageable);
}
