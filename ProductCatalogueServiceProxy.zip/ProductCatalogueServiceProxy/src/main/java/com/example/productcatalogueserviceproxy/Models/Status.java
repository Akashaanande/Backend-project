package com.example.productcatalogueserviceproxy.Models;

public enum Status {

    ACTIVE,INACTIVE;
}
