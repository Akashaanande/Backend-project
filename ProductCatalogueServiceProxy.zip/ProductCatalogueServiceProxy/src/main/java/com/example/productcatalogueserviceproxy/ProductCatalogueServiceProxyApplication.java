package com.example.productcatalogueserviceproxy;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProductCatalogueServiceProxyApplication {

    public static void main(String[] args) {
        SpringApplication.run(ProductCatalogueServiceProxyApplication.class, args);
    }

}
