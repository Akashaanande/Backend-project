package com.example.productcatalogueserviceproxy.Models;

public enum SortType {
    ASC,DESC
}