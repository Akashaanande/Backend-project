package com.example.productcatalogueserviceproxy.Services;

import com.example.productcatalogueserviceproxy.Dtos.ProductDto;
import com.example.productcatalogueserviceproxy.Models.Product;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;

import java.util.List;

public interface IProductService {
    List<Product> getProducts();

    Product getProduct(Long productId);

    Product createProduct( Product product);

    Product updateProducts( Long id, Product product);
    Product getProductDetails(Long userId, Long productId);
}
