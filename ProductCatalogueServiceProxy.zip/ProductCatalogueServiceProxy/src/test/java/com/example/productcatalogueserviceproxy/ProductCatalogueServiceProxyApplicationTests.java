package com.example.productcatalogueserviceproxy;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProductCatalogueServiceProxyApplicationTests {

    @Test
    void contextLoads() {
    }

}
